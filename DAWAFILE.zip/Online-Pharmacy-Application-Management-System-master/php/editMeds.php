
<?php

include("includes.php"); // Contain all necessary include files 
/* THIS PAGE IS FOR SALESPERSON to edit meds */
?>
<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8">
        <title>
            <!-- Place Title Here  -->
        </title>
        <link rel="stylesheet" href="../css/style.css" />
    </head>

    <body>

        <div class="form">

            <?php include("nav_menu.php"); ?>

                <div>

                    <h1> <!-- Insert Page Name Here --> </h1>

                    <!-- INSERT YOUR HTML CODE AFTER THIS LINE -->

                    <!-- INSERT YOUR HTML CODE BEFORE THIS LINE -->

                    <br />
                    <br />
                    <br />
                    <br />
                </div>
        </div>
    </body>
</html>
