<?php

/* This file will include all of the necessary required and include files in one place */

require('db.php');
include("auth.php"); //include auth.php file on all secure pages
	

?>
