<?php
 
require('db.php');
include("auth.php"); //include auth.php file on all secure pages 

?>
<!DOCTYPE html>
<html>
    <head>
   	<meta charset="utf-8">
	<title>	<!-- Place Title Here  --> </title>
	<link rel="stylesheet" href="../css/style.css" />
    </head>
    <body>

    	<div class="form">
	
    	    <p> <!-- Place Page Name Here --> </p>

    	    <?php include("nav_menu.php"); ?>

     	    <!-- INSERT YOUR CODE AFTER THIS LINE --> 


     	    <!-- INSERT YOUR CODE BEFORE THIS LINE --> 

    	    <br /><br /><br /><br />

        </div>
    </body>
</html>
