<?php

include("includes.php"); // Contain all necessary include files 

echo "Delete NOT ALLOWED!" 

?>
<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8">
        <title>
            ERROR!
        </title>
        <link rel="stylesheet" href="../css/style.css" />
    </head>

    <body>

        <div class="form">

            <?php include("nav_menu.php"); ?>

                <div>

                    <h1> Cannot delete or update a parent row! A foreign key constraint fails! </h1>

                    <!-- INSERT YOUR HTML CODE AFTER THIS LINE -->

                    <!-- INSERT YOUR HTML CODE BEFORE THIS LINE -->

                    <br />
                    <br />
                    <br />
                    <br />
                </div>
        </div>
    </body>
</html>
