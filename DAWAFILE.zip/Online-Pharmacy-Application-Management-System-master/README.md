# Online-Pharmacy-Application-Management-System
The pharmacy application system has an inventory of over the counter (OTC) medicines packages, hereinafter referred simply as Medicine for brevity, categorized by disease/ailment type, that can be browsed and searched by customers on the website and can be added to the cart to make a purchase.
